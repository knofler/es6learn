async function runStream(url) {
    const error = {
        "noStream": {
            stream: "None",
            health: "Unhealthy",
            code: 404
        },
        "mp3": {
            stream: "MP3",
            health: "Partial Stream Available",
            code: 503
        },
        "aac": {
            stream: "AAC",
            health: "Major Stream Available",
            code: 206
        },
        "all": {
            stream: "All Stream Running",
            health: "Healthy",
            code: 200
        }
    }

    var status = {}

    var stream = await fetch(url)
        .then((resp) => resp.json())
        .then(function (data) {
            if (data.icestats.source == undefined) {
                status = error.noStream
            } else if (data.icestats.source !== undefined) {
                let source = data.icestats.source
                if (source.server_type == "audio/mp3") {
                    status = error.mp3
                } else if (source.server_type == "audio/aacp") {
                    status = error.aac
                } else {
                    status = error.all
                }
                // console.log(data.icestats)
            }

        })
    console.log(status)
}

var localurl = "http://localhost:8000/status-json.xsl";
var dnOpsUrl = "http://wowza-ice-lbicecas-t28n5d2d8gzy-752305912.ap-southeast-2.elb.amazonaws.com/status-json.xsl";
var prodUrl = "http://jjj-loadbalancer-network-5b5007a4a6002723.elb.ap-southeast-2.amazonaws.com/status-json.xsl"

var status = runStream(localurl)

console.log("Stream status :", status)